
import 'package:flutter/material.dart';

void main() {
  runApp(const PopTubeApp());
}

class PopTubeApp extends StatelessWidget {
  const PopTubeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pop Tube V61',
      theme: ThemeData.dark(),
      home: const WalletHomePage(),
    );
  }
}

class WalletHomePage extends StatelessWidget {
  const WalletHomePage({super.key});

  void _openLiveStreamPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const LiveStreamPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("محفظة PopCoin"),
        actions: [
          IconButton(
            onPressed: () => _openLiveStreamPage(context),
            icon: const Icon(Icons.videocam),
          ),
        ],
      ),
      body: const Center(
        child: Text("مرحبًا بك في Pop Tube V61!"),
      ),
    );
  }
}

class LiveStreamPage extends StatefulWidget {
  const LiveStreamPage({super.key});

  @override
  State<LiveStreamPage> createState() => _LiveStreamPageState();
}

class _LiveStreamPageState extends State<LiveStreamPage> {
  bool isStreaming = false;
  String statusMessage = "لم يبدأ البث بعد.";
  int viewerCount = 0;
  List<String> chatMessages = [
    "مرحبا! أهلا بكم في البث المباشر.",
  ];
  final TextEditingController chatController = TextEditingController();

  final List<String> bannedWords = [
    "إهانة",
    "سوء",
    "شتيمة",
    "عنصرية",
    "سب"
  ];

  void startStream() {
    setState(() {
      isStreaming = true;
      viewerCount = 5; // عدد افتراضي للمشاهدين
      statusMessage = "🚀 البث المباشر قيد التشغيل.";
    });
  }

  void stopStream() {
    setState(() {
      isStreaming = false;
      viewerCount = 0;
      statusMessage = "تم إيقاف البث.";
    });
  }

  void sendChatMessage() {
    final msg = chatController.text.trim();
    if (msg.isEmpty) return;

    for (var word in bannedWords) {
      if (msg.contains(word)) {
        _showSnackbar("🚫 الرسالة تحتوي على كلمات غير لائقة!");
        return;
      }
    }

    setState(() {
      chatMessages.add(msg);
    });
    chatController.clear();
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("البث المباشر")),
      body: Column(
        children: [
          Expanded(
            child: Column(
              children: [
                const SizedBox(height: 10),
                Text(
                  "عدد المشاهدين: $viewerCount",
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: chatMessages.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        leading: const Icon(Icons.chat),
                        title: Text(chatMessages[index]),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: chatController,
                    decoration: const InputDecoration(
                      hintText: "اكتب تعليقك هنا...",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: sendChatMessage,
                  icon: const Icon(Icons.send),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: isStreaming ? stopStream : startStream,
            style: ElevatedButton.styleFrom(
              backgroundColor: isStreaming ? Colors.red : Colors.green,
            ),
            child: Text(isStreaming ? "إيقاف البث" : "بدء البث"),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
